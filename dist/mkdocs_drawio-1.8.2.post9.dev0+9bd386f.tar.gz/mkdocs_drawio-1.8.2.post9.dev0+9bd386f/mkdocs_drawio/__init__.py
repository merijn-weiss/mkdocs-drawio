from .plugin import DrawioPlugin

__all__ = [DrawioPlugin]
